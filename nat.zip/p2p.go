package main

import (
	"log"
	"test/nat"
	"time"
)

func main() {
	var quit chan struct{}
	NAT := nat.Any()
	if NAT != nil {
		nat.Map(NAT, quit, "udp", 12345, 12345, "ethereum discovery")

		if ext, err := NAT.ExternalIP(); err == nil {
			log.Println(ext)
		}
	}
	time.Sleep(30 * time.Second)
}
